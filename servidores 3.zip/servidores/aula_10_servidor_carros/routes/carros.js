const express = require('express');
const router = express.Router();
const Carro = require('../models/Carro');

// Middleware de autenticação
function autenticado(req, res, next) {
  if (req.session.usuario) return next();
  req.flash('error', 'Faça login para acessar esta página.');
  res.redirect('/usuarios/login');
}

// GET - Listagem pública de carros disponíveis
router.get('/listagem', async (req, res) => {
  try {
    const carros = await Carro.find().sort({ marca: 1, modelo: 1 });
    res.render('carros/listagem', { carros });
  } catch (err) {
    req.flash('error', 'Erro ao buscar carros.');
    res.redirect('/');
  }
});

// GET - Página de gerência (protegida)
router.get('/gerencia', autenticado, async (req, res) => {
  try {
    const carros = await Carro.find().sort({ marca: 1 });
    res.render('carros/gerencia', { carros });
  } catch (err) {
    req.flash('error', 'Erro ao carregar gerência.');
    res.redirect('/');
  }
});

// POST - Cadastrar novo carro
router.post('/', autenticado, async (req, res) => {
  try {
    const { marca, modelo, ano, qtde_disponivel } = req.body;
    await Carro.create({ marca, modelo, ano: Number(ano), qtde_disponivel: Number(qtde_disponivel) });
    req.flash('success', 'Carro cadastrado com sucesso!');
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error', 'Erro ao cadastrar carro.');
    res.redirect('/carros/gerencia');
  }
});

// PUT - Atualizar carro
router.put('/:id', autenticado, async (req, res) => {
  try {
    const { marca, modelo, ano, qtde_disponivel } = req.body;
    await Carro.findByIdAndUpdate(req.params.id, {
      marca, modelo, ano: Number(ano), qtde_disponivel: Number(qtde_disponivel)
    });
    req.flash('success', 'Carro atualizado com sucesso!');
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error', 'Erro ao atualizar carro.');
    res.redirect('/carros/gerencia');
  }
});

// POST - Vender carro (decrementa quantidade)
router.post('/:id/vender', autenticado, async (req, res) => {
  try {
    const carro = await Carro.findById(req.params.id);
    if (!carro) {
      req.flash('error', 'Carro não encontrado.');
      return res.redirect('/carros/gerencia');
    }
    if (carro.qtde_disponivel <= 0) {
      req.flash('error', `"${carro.marca} ${carro.modelo}" está Esgotado!`);
      return res.redirect('/carros/gerencia');
    }
    carro.qtde_disponivel -= 1;
    await carro.save();
    if (carro.qtde_disponivel === 0) {
      req.flash('error', `Venda realizada! "${carro.marca} ${carro.modelo}" está agora Esgotado!`);
    } else {
      req.flash('success', `Venda realizada! Restam ${carro.qtde_disponivel} unidade(s).`);
    }
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error', 'Erro ao vender carro.');
    res.redirect('/carros/gerencia');
  }
});

// DELETE - Remover carro
router.delete('/:id', autenticado, async (req, res) => {
  try {
    await Carro.findByIdAndDelete(req.params.id);
    req.flash('success', 'Carro removido com sucesso!');
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error', 'Erro ao remover carro.');
    res.redirect('/carros/gerencia');
  }
});

module.exports = router;
