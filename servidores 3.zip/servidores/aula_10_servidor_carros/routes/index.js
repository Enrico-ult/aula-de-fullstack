const express = require('express');
const router = express.Router();

// Redireciona '/' para a página de projetos
router.get('/', (req, res) => {
  res.redirect('/projetos');
});

// Página de projetos
router.get('/projetos', (req, res) => {
  res.render('projetos');
});

module.exports = router;
