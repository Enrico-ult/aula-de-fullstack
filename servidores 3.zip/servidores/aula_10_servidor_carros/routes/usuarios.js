const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');

// GET - Formulário de cadastro
router.get('/cadastro', (req, res) => {
  res.render('usuarios/cadastro');
});

// POST - Criar usuário
router.post('/cadastro', async (req, res) => {
  try {
    const { nome, login, senha } = req.body;

    const existe = await Usuario.findOne({ login });
    if (existe) {
      req.flash('error', 'Login já está em uso. Escolha outro.');
      return res.redirect('/usuarios/cadastro');
    }

    await Usuario.create({ nome, login, senha });
    req.flash('success', 'Usuário cadastrado com sucesso! Faça o login.');
    res.redirect('/usuarios/login');
  } catch (err) {
    req.flash('error', 'Erro ao cadastrar usuário.');
    res.redirect('/usuarios/cadastro');
  }
});

// GET - Formulário de login
router.get('/login', (req, res) => {
  if (req.session.usuario) return res.redirect('/carros/gerencia');
  res.render('usuarios/login');
});

// POST - Autenticar usuário
router.post('/login', async (req, res) => {
  try {
    const { login, senha } = req.body;
    const usuario = await Usuario.findOne({ login });

    if (!usuario || !(await usuario.compararSenha(senha))) {
      req.flash('error', 'Login ou senha inválidos.');
      return res.redirect('/usuarios/login');
    }

    req.session.usuario = { id: usuario._id, nome: usuario.nome, login: usuario.login };
    req.flash('success', `Bem-vindo, ${usuario.nome}!`);
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error', 'Erro ao fazer login.');
    res.redirect('/usuarios/login');
  }
});

// GET - Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/usuarios/login');
});

module.exports = router;
