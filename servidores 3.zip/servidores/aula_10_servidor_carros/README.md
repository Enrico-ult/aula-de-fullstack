# 🚗 Carros App — Sistema de Gerenciamento de Venda de Carros

## 📋 Tecnologias
- **Node.js** + **Express** — servidor web
- **EJS** — templates dinâmicos
- **MongoDB** + **Mongoose** — banco de dados
- **bcryptjs** — hash de senhas
- **express-session** — sessões de login

## ⚙️ Como rodar

### 1. Instalar dependências
```bash
npm install
```

### 2. Ter MongoDB rodando localmente
```bash
# Linux/Mac
sudo systemctl start mongod
# ou
mongod --dbpath /data/db
```

### 3. Iniciar o servidor
```bash
# Porta 80 (precisa de sudo no Linux/Mac)
sudo node server.js

# Para desenvolvimento com hot-reload
sudo npx nodemon server.js
```

### 4. Acessar no navegador
```
http://localhost
```

## 📁 Estrutura do Projeto

```
carros-app/
├── server.js              # Ponto de entrada
├── package.json
├── models/
│   ├── Usuario.js         # Schema: Nome, Login, Senha
│   └── Carro.js           # Schema: Marca, Modelo, Ano, Qtde_disponivel
├── routes/
│   ├── index.js           # / → /projetos
│   ├── usuarios.js        # cadastro, login, logout
│   └── carros.js          # CRUD completo
├── views/
│   ├── partials/
│   │   ├── header.ejs
│   │   └── footer.ejs
│   ├── projetos.ejs       # Página de projetos (tabela com link "Carros")
│   ├── usuarios/
│   │   ├── cadastro.ejs
│   │   └── login.ejs
│   └── carros/
│       ├── listagem.ejs   # Listagem pública
│       └── gerencia.ejs   # Gerência (protegida por login)
└── public/
    └── css/style.css
```

## 🔗 Rotas

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | / | Redireciona para /projetos |
| GET | /projetos | Página de projetos |
| GET | /usuarios/cadastro | Formulário de cadastro |
| POST | /usuarios/cadastro | Cria usuário |
| GET | /usuarios/login | Formulário de login |
| POST | /usuarios/login | Autentica usuário |
| GET | /usuarios/logout | Encerra sessão |
| GET | /carros/listagem | Lista pública de carros |
| GET | /carros/gerencia | Gerência (requer login) |
| POST | /carros | Cadastrar carro |
| PUT | /carros/:id | Atualizar carro |
| POST | /carros/:id/vender | Vender (decrementa qtd) |
| DELETE | /carros/:id | Remover carro |

## 🗄️ Coleções MongoDB

### Usuarios
```json
{ "nome": "string", "login": "string", "senha": "hash" }
```

### Carros
```json
{ "marca": "string", "modelo": "string", "ano": "number", "qtde_disponivel": "number" }
```
