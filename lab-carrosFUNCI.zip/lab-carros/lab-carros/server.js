const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4', '1.1.1.1']); // Força DNS público (Google + Cloudflare)

const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');

const app = express();
const PORT = 80;

// ─── Conexão MongoDB ─────────────────────────────────────────────────────────
const MONGO_URI = 'mongodb+srv://zafanellaccenrico_db_user:Enrico212322vi-se@cluster0.efx9irw.mongodb.net/?appName=Cluster0';
const DB_NAME   = 'gerencia_carros';
let db;

MongoClient.connect(MONGO_URI)
  .then(client => {
    db = client.db(DB_NAME);
    console.log('✅ Conectado ao MongoDB!');
    app.listen(PORT, () => {
      console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('❌ Erro ao conectar ao MongoDB:', err.message);
    process.exit(1);
  });

// ─── Middlewares ──────────────────────────────────────────────────────────────
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(session({
  secret: 'fei_lab_carros_2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

// ─── Middleware de Autenticação ───────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session.usuario) return next();
  res.redirect('/login');
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROTAS PÚBLICAS
// ═══════════════════════════════════════════════════════════════════════════════

// '/' → redireciona para listagem de carros (página de projetos)
app.get('/', (req, res) => res.redirect('/carros'));

// ── Listagem pública de carros ─────────────────────────────────────────────
app.get('/carros', async (req, res) => {
  try {
    const carros = await db.collection('carros').find({}).toArray();
    res.render('carros', { carros, usuario: req.session.usuario || null });
  } catch (err) {
    res.status(500).send('Erro ao buscar carros: ' + err.message);
  }
});

// ── Cadastro de Usuário ────────────────────────────────────────────────────
app.get('/cadastro', (req, res) => {
  res.render('cadastro', { erro: null, sucesso: null });
});

app.post('/cadastro', async (req, res) => {
  const { nome, login, senha } = req.body;
  try {
    const jaExiste = await db.collection('usuarios').findOne({ login });
    if (jaExiste) {
      return res.render('cadastro', { erro: 'Login já está em uso!', sucesso: null });
    }
    const senhaCriptografada = await bcrypt.hash(senha, 10);
    // CREATE – inserir novo usuário
    await db.collection('usuarios').insertOne({ nome, login, senha: senhaCriptografada });
    res.render('cadastro', { erro: null, sucesso: 'Cadastro realizado! Faça login.' });
  } catch (err) {
    res.render('cadastro', { erro: 'Erro: ' + err.message, sucesso: null });
  }
});

// ── Login de Usuário ───────────────────────────────────────────────────────
app.get('/login', (req, res) => {
  if (req.session.usuario) return res.redirect('/gerencia');
  res.render('login', { erro: null });
});

app.post('/login', async (req, res) => {
  const { login, senha } = req.body;
  try {
    // READ – buscar usuário
    const usuario = await db.collection('usuarios').findOne({ login });
    if (!usuario) return res.render('login', { erro: 'Usuário não encontrado!' });

    const senhaOk = await bcrypt.compare(senha, usuario.senha);
    if (!senhaOk) return res.render('login', { erro: 'Senha incorreta!' });

    req.session.usuario = { id: usuario._id.toString(), nome: usuario.nome, login: usuario.login };
    res.redirect('/gerencia');
  } catch (err) {
    res.render('login', { erro: 'Erro: ' + err.message });
  }
});

// ── Logout ─────────────────────────────────────────────────────────────────
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROTAS PROTEGIDAS – GERÊNCIA DE CARROS
// ═══════════════════════════════════════════════════════════════════════════════

// ── Listar carros (tabela de gerência) ────────────────────────────────────
app.get('/gerencia', requireAuth, async (req, res) => {
  try {
    // READ – buscar todos os carros
    const carros = await db.collection('carros').find({}).toArray();
    res.render('gerencia', { carros, usuario: req.session.usuario });
  } catch (err) {
    res.status(500).send('Erro: ' + err.message);
  }
});

// ── CREATE – Cadastrar novo carro ─────────────────────────────────────────
app.get('/gerencia/novo', requireAuth, (req, res) => {
  res.render('novo', { usuario: req.session.usuario, erro: null });
});

app.post('/gerencia/novo', requireAuth, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body;
  try {
    await db.collection('carros').insertOne({
      marca,
      modelo,
      ano: parseInt(ano),
      qtde_disponivel: parseInt(qtde_disponivel)
    });
    res.redirect('/gerencia');
  } catch (err) {
    res.render('novo', { usuario: req.session.usuario, erro: 'Erro: ' + err.message });
  }
});

// ── UPDATE – Atualizar carro ──────────────────────────────────────────────
app.get('/gerencia/atualizar/:id', requireAuth, async (req, res) => {
  try {
    const carro = await db.collection('carros').findOne({ _id: new ObjectId(req.params.id) });
    if (!carro) return res.redirect('/gerencia');
    res.render('atualizar', { carro, usuario: req.session.usuario, erro: null });
  } catch (err) {
    res.status(500).send('Erro: ' + err.message);
  }
});

app.post('/gerencia/atualizar/:id', requireAuth, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body;
  try {
    await db.collection('carros').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { marca, modelo, ano: parseInt(ano), qtde_disponivel: parseInt(qtde_disponivel) } }
    );
    res.redirect('/gerencia');
  } catch (err) {
    const carro = { _id: req.params.id, ...req.body };
    res.render('atualizar', { carro, usuario: req.session.usuario, erro: 'Erro: ' + err.message });
  }
});

// ── DELETE – Remover carro ────────────────────────────────────────────────
app.post('/gerencia/remover/:id', requireAuth, async (req, res) => {
  try {
    await db.collection('carros').deleteOne({ _id: new ObjectId(req.params.id) });
    res.redirect('/gerencia');
  } catch (err) {
    res.status(500).send('Erro ao remover: ' + err.message);
  }
});

// ── VENDER – Decrementar quantidade ──────────────────────────────────────
app.post('/gerencia/vender/:id', requireAuth, async (req, res) => {
  try {
    const carro = await db.collection('carros').findOne({ _id: new ObjectId(req.params.id) });
    if (!carro) return res.redirect('/gerencia');

    if (carro.qtde_disponivel > 0) {
      await db.collection('carros').updateOne(
        { _id: new ObjectId(req.params.id) },
        { $inc: { qtde_disponivel: -1 } }  // decrementa 1
      );
    }
    res.redirect('/gerencia');
  } catch (err) {
    res.status(500).send('Erro ao vender: ' + err.message);
  }
});
