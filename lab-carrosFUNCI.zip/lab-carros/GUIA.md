# 🚗 Guia Completo — Lab Gerência de Carros (FEI)

---

## PASSO 0 — Instalar o Node.js (pré-requisito obrigatório)

O `npm` faz parte do **Node.js**. Se `npm install` não funciona, é porque o Node.js não está instalado.

Escolha o comando de acordo com seu sistema operacional:

---

### 🪟 Windows

Abra o **PowerShell como Administrador** e rode:

```powershell
winget install OpenJS.NodeJS.LTS
```

> O `winget` já vem instalado no Windows 10/11. Se não funcionar, atualize a Microsoft Store.

---

### 🐧 Linux (Ubuntu / Debian)

```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs
```

---

### 🍎 macOS

```bash
brew install node
```

> Se não tiver o Homebrew: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`

---

### Verificar se instalou corretamente

**Feche o terminal e abra um novo**, depois rode:

```bash
node -v
npm -v
```

Se aparecer algo como `v20.x.x` e `10.x.x`, está pronto. Agora o `npm install` vai funcionar.

---

## PASSO 0.5 — Corrigir erro de DNS (se aparecer `querySrv ECONNREFUSED`)

Se ao rodar `node server.js` aparecer o erro:
```
Erro ao conectar ao MongoDB: querySrv ECONNREFUSED _mongodb._tcp.cluster0...
```

Isso significa que o DNS da sua rede está bloqueando a conexão com o MongoDB Atlas. A solução mais rápida é forçar o uso de DNS público **diretamente no código**, sem mexer nas configurações do Windows.

Abra o `server.js` e adicione estas duas linhas no **topo do arquivo** (antes de tudo):

```js
const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4', '1.1.1.1']);
```

> Isso força o Node.js a usar os servidores DNS do **Google** (8.8.8.8 / 8.8.4.4) e **Cloudflare** (1.1.1.1), ignorando o DNS padrão da rede que estava bloqueando.

> ✅ O `dns` já vem com o Node.js — não precisa instalar nada.

---

## PASSO 1 — Baixar e extrair o projeto

1. Baixe o arquivo **`lab-carros.zip`**
2. Extraia em uma pasta de sua escolha, por exemplo:
   ```
   C:\Users\SeuNome\Desktop\lab-carros
   ```
3. Abra a pasta. Você deve ver:
   ```
   lab-carros/
   ├── server.js
   ├── package.json
   ├── public/
   │   └── style.css
   └── views/
       ├── cadastro.ejs
       ├── login.ejs
       ├── carros.ejs
       ├── gerencia.ejs
       ├── novo.ejs
       └── atualizar.ejs
   ```

---

## PASSO 2 — Abrir o terminal na pasta do projeto

**Windows:**
- Abra a pasta no Explorador de Arquivos
- Clique na barra de endereço, digite `cmd` e pressione Enter

**VS Code (recomendado):**
- Abra o VS Code → `File > Open Folder` → selecione `lab-carros`
- `Terminal > New Terminal`

---

## PASSO 3 — Instalar as dependências

No terminal, dentro da pasta `lab-carros`, rode:

```bash
npm install
```

Isso vai criar a pasta `node_modules` com todos os pacotes necessários:

| Pacote | Para que serve |
|---|---|
| `express` | Servidor web |
| `ejs` | Páginas dinâmicas |
| `mongodb` | Banco de dados |
| `express-session` | Controle de login/sessão |
| `bcryptjs` | Criptografia de senha |

> ⏳ Aguarde terminar (alguns segundos). Vai aparecer `found 0 vulnerabilities`.

---

## PASSO 4 — Iniciar o servidor

```bash
node server.js
```

Se aparecer isso no terminal, está funcionando:

```
✅ Conectado ao MongoDB!
🚀 Servidor rodando em http://localhost:80
```

> ⚠️ **No Windows**, a porta 80 pode pedir permissão de administrador.  
> Se der erro, abra o `cmd` como **Administrador** e tente novamente.

---

## PASSO 5 — Acessar no navegador

Abra o navegador e acesse:

```
http://localhost
```

Você será redirecionado automaticamente para a **listagem de carros**.

---

## PASSO 6 — Usar o sistema

Siga esta ordem na primeira vez:

### 6.1 — Criar uma conta
- Acesse: `http://localhost/cadastro`
- Preencha **Nome**, **Login** e **Senha**
- Clique em **Cadastrar**

### 6.2 — Fazer login
- Acesse: `http://localhost/login`
- Use o login e senha que você criou
- Você será redirecionado para a **Gerência**

### 6.3 — Cadastrar um carro
- Na página de Gerência, clique em **+ Cadastrar Novo Carro**
- Preencha: Marca, Modelo, Ano e Quantidade
- Clique em **Cadastrar Carro**

### 6.4 — Testar as operações

| Botão | O que faz |
|---|---|
| 🛒 **Vender** | Diminui 1 da quantidade. Fica desabilitado se chegar a zero. |
| ✏️ **Editar** | Abre formulário com os dados atuais para alterar |
| 🗑️ **Remover** | Deleta o carro do banco (pede confirmação) |

### 6.5 — Ver o catálogo público
- Acesse: `http://localhost/carros`
- Mostra todos os carros com o badge **✅ Disponível** ou **⚠️ Esgotado**
- Esta página funciona **sem precisar de login**

---

## Resumo das páginas

| URL | Página | Login necessário? |
|---|---|---|
| `http://localhost/` | Redireciona para catálogo | Não |
| `http://localhost/carros` | Catálogo público | Não |
| `http://localhost/cadastro` | Criar conta | Não |
| `http://localhost/login` | Entrar no sistema | Não |
| `http://localhost/gerencia` | Gerenciar carros | ✅ Sim |
| `http://localhost/gerencia/novo` | Cadastrar carro | ✅ Sim |
| `http://localhost/logout` | Sair da conta | ✅ Sim |

---

## ❌ Possíveis erros e soluções

| Erro | Causa | Solução |
|---|---|---|
| `EACCES: permission denied` (porta 80) | Sem permissão de admin | Rode o terminal como Administrador |
| `npm não é reconhecido` | Node.js não está instalado | Instale o Node.js (Passo 0) e reinicie o PC |
| `Cannot find module 'express'` | node_modules ausente | Rode `npm install` novamente |
| `MongoServerError` | Problema de conexão | Verifique sua internet (o banco é online) |
| Página em branco / erro 500 | Erro no servidor | Veja o terminal onde rodou `node server.js` |

---

## ⏹️ Parar o servidor

No terminal onde está rodando, pressione:

```
Ctrl + C
```
